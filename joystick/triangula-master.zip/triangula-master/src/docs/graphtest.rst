Just to show we can do graphs and maths
=======================================

.. graphviz::

    digraph G {
        a->b->c;
        b->d;
        a [fillcolor=pink,style=filled];
        c [label="hello world"]
        d [];
        e [];
    }
