# Triangula
Code and plans for BaseBot's big sister Triangula, renamed from Triangulon as it was pointed out that the latter wasn't particularly feminine!
